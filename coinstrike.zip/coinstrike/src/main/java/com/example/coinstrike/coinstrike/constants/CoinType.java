package com.example.coinstrike.coinstrike.constants;
/* 
    This enum is used to idenfity the coin type through out the application
 */
public enum CoinType {
    RED,
    BLACK
}
